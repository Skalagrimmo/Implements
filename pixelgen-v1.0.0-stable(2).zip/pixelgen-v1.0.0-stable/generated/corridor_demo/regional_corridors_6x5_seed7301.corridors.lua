return {
  corridors = {
    {
      id = "corridor_01_old_road",
      kind = "old_road",
      metadata = {
        tier = "world",
      },
      path = {
        {
          0,
          0,
        },
        {
          0,
          1,
        },
        {
          0,
          2,
        },
        {
          1,
          2,
        },
        {
          2,
          2,
        },
        {
          3,
          2,
        },
      },
      purpose = "world_spine",
      sector_count = 6,
      source = {
        0,
        0,
      },
      target = {
        3,
        2,
      },
      visual_material = "road",
    },
    {
      id = "corridor_02_old_road",
      kind = "old_road",
      metadata = {
        primary_biome = "dark_forest",
        region_id = 0,
        tier = "regional",
      },
      path = {
        {
          2,
          1,
        },
        {
          2,
          2,
        },
      },
      purpose = "region_connector",
      sector_count = 2,
      source = {
        2,
        1,
      },
      target = {
        2,
        2,
      },
      visual_material = "road",
    },
    {
      id = "corridor_03_old_road",
      kind = "old_road",
      metadata = {
        primary_biome = "ruined_settlement",
        region_id = 1,
        tier = "regional",
      },
      path = {
        {
          5,
          4,
        },
        {
          4,
          4,
        },
        {
          4,
          3,
        },
        {
          3,
          3,
        },
        {
          3,
          2,
        },
      },
      purpose = "region_connector",
      sector_count = 5,
      source = {
        5,
        4,
      },
      target = {
        3,
        2,
      },
      visual_material = "road",
    },
    {
      id = "corridor_04_pilgrim_route",
      kind = "pilgrim_route",
      metadata = {
        primary_biome = "reformed_chapel",
        region_id = 2,
        tier = "regional",
      },
      path = {
        {
          0,
          4,
        },
        {
          0,
          3,
        },
        {
          0,
          2,
        },
      },
      purpose = "region_connector",
      sector_count = 3,
      source = {
        0,
        4,
      },
      target = {
        0,
        2,
      },
      visual_material = "pilgrim_paving",
    },
    {
      id = "corridor_05_silt_vein",
      kind = "silt_vein",
      metadata = {
        landmark_id = "regional_02_nanolith_shrine",
        landmark_kind = "nanolith_shrine",
        tier = "regional",
      },
      path = {
        {
          1,
          0,
        },
        {
          0,
          0,
        },
      },
      purpose = "landmark_spur",
      sector_count = 2,
      source = {
        1,
        0,
      },
      target = {
        0,
        0,
      },
      visual_material = "silt_trace",
    },
    {
      id = "corridor_06_silt_vein",
      kind = "silt_vein",
      metadata = {
        landmark_id = "regional_03_nanolith_shrine",
        landmark_kind = "nanolith_shrine",
        tier = "regional",
      },
      path = {
        {
          5,
          0,
        },
        {
          4,
          0,
        },
        {
          3,
          0,
        },
        {
          2,
          0,
        },
        {
          1,
          0,
        },
      },
      purpose = "landmark_spur",
      sector_count = 5,
      source = {
        5,
        0,
      },
      target = {
        1,
        0,
      },
      visual_material = "silt_trace",
    },
    {
      id = "corridor_07_silt_vein",
      kind = "silt_vein",
      metadata = {
        landmark_id = "regional_05_nanolith_shrine",
        landmark_kind = "nanolith_shrine",
        tier = "regional",
      },
      path = {
        {
          2,
          3,
        },
        {
          2,
          2,
        },
      },
      purpose = "landmark_spur",
      sector_count = 2,
      source = {
        2,
        3,
      },
      target = {
        2,
        2,
      },
      visual_material = "silt_trace",
    },
  },
  local_realization = {
    {
      anchors = {
        {
          coord = 9,
          edge = "S",
          to = {
            0,
            1,
          },
          x = 9,
          y = 14,
        },
      },
      corridor_id = "corridor_01_old_road",
      kind = "old_road",
      path_index = 0,
      purpose = "world_spine",
      route_cells = {
        {
          9,
          14,
        },
        {
          8,
          14,
        },
        {
          7,
          14,
        },
        {
          6,
          14,
        },
        {
          5,
          14,
        },
        {
          4,
          14,
        },
        {
          3,
          14,
        },
        {
          2,
          14,
        },
        {
          2,
          13,
        },
        {
          2,
          12,
        },
      },
      sector = {
        0,
        0,
      },
      visual_material = "road",
    },
    {
      anchors = {
        {
          coord = 9,
          edge = "N",
          to = {
            0,
            0,
          },
          x = 9,
          y = 0,
        },
        {
          coord = 14,
          edge = "S",
          to = {
            0,
            2,
          },
          x = 14,
          y = 14,
        },
      },
      corridor_id = "corridor_01_old_road",
      kind = "old_road",
      path_index = 1,
      purpose = "world_spine",
      route_cells = {
        {
          9,
          0,
        },
        {
          10,
          0,
        },
        {
          11,
          0,
        },
        {
          12,
          0,
        },
        {
          13,
          0,
        },
        {
          13,
          1,
        },
        {
          13,
          2,
        },
        {
          14,
          2,
        },
        {
          14,
          3,
        },
        {
          14,
          4,
        },
        {
          14,
          5,
        },
        {
          14,
          6,
        },
        {
          14,
          7,
        },
        {
          14,
          8,
        },
        {
          14,
          9,
        },
        {
          14,
          10,
        },
        {
          14,
          11,
        },
        {
          14,
          12,
        },
        {
          14,
          13,
        },
        {
          14,
          14,
        },
      },
      sector = {
        0,
        1,
      },
      visual_material = "road",
    },
    {
      anchors = {
        {
          coord = 14,
          edge = "N",
          to = {
            0,
            1,
          },
          x = 14,
          y = 0,
        },
        {
          coord = 11,
          edge = "E",
          to = {
            1,
            2,
          },
          x = 19,
          y = 11,
        },
      },
      corridor_id = "corridor_01_old_road",
      kind = "old_road",
      path_index = 2,
      purpose = "world_spine",
      route_cells = {
        {
          14,
          0,
        },
        {
          15,
          0,
        },
        {
          16,
          0,
        },
        {
          17,
          0,
        },
        {
          18,
          0,
        },
        {
          19,
          0,
        },
        {
          19,
          1,
        },
        {
          19,
          2,
        },
        {
          19,
          3,
        },
        {
          19,
          4,
        },
        {
          19,
          5,
        },
        {
          19,
          6,
        },
        {
          19,
          7,
        },
        {
          19,
          8,
        },
        {
          19,
          9,
        },
        {
          19,
          10,
        },
        {
          19,
          11,
        },
      },
      sector = {
        0,
        2,
      },
      visual_material = "road",
    },
    {
      anchors = {
        {
          coord = 11,
          edge = "W",
          to = {
            0,
            2,
          },
          x = 0,
          y = 11,
        },
        {
          coord = 11,
          edge = "E",
          to = {
            2,
            2,
          },
          x = 19,
          y = 11,
        },
      },
      corridor_id = "corridor_01_old_road",
      kind = "old_road",
      path_index = 3,
      purpose = "world_spine",
      route_cells = {
        {
          0,
          11,
        },
        {
          1,
          11,
        },
        {
          2,
          11,
        },
        {
          3,
          11,
        },
        {
          4,
          11,
        },
        {
          5,
          11,
        },
        {
          6,
          11,
        },
        {
          7,
          11,
        },
        {
          8,
          11,
        },
        {
          9,
          11,
        },
        {
          10,
          11,
        },
        {
          10,
          10,
        },
        {
          11,
          10,
        },
        {
          12,
          10,
        },
        {
          13,
          10,
        },
        {
          14,
          10,
        },
        {
          15,
          10,
        },
        {
          16,
          10,
        },
        {
          17,
          10,
        },
        {
          18,
          10,
        },
        {
          19,
          10,
        },
        {
          19,
          11,
        },
      },
      sector = {
        1,
        2,
      },
      visual_material = "road",
    },
    {
      anchors = {
        {
          coord = 11,
          edge = "W",
          to = {
            1,
            2,
          },
          x = 0,
          y = 11,
        },
        {
          coord = 11,
          edge = "E",
          to = {
            3,
            2,
          },
          x = 19,
          y = 11,
        },
      },
      corridor_id = "corridor_01_old_road",
      kind = "old_road",
      path_index = 4,
      purpose = "world_spine",
      route_cells = {
        {
          0,
          11,
        },
        {
          1,
          11,
        },
        {
          2,
          11,
        },
        {
          3,
          11,
        },
        {
          4,
          11,
        },
        {
          5,
          11,
        },
        {
          6,
          11,
        },
        {
          7,
          11,
        },
        {
          8,
          11,
        },
        {
          9,
          11,
        },
        {
          10,
          11,
        },
        {
          10,
          12,
        },
        {
          11,
          12,
        },
        {
          12,
          12,
        },
        {
          13,
          12,
        },
        {
          13,
          11,
        },
        {
          14,
          11,
        },
        {
          15,
          11,
        },
        {
          16,
          11,
        },
        {
          17,
          11,
        },
        {
          18,
          11,
        },
        {
          19,
          11,
        },
      },
      sector = {
        2,
        2,
      },
      visual_material = "road",
    },
    {
      anchors = {
        {
          coord = 11,
          edge = "W",
          to = {
            2,
            2,
          },
          x = 0,
          y = 11,
        },
      },
      corridor_id = "corridor_01_old_road",
      kind = "old_road",
      path_index = 5,
      purpose = "world_spine",
      route_cells = {
        {
          0,
          11,
        },
        {
          1,
          11,
        },
        {
          2,
          11,
        },
        {
          2,
          12,
        },
      },
      sector = {
        3,
        2,
      },
      visual_material = "road",
    },
    {
      anchors = {
        {
          coord = 12,
          edge = "S",
          to = {
            2,
            2,
          },
          x = 12,
          y = 14,
        },
      },
      corridor_id = "corridor_02_old_road",
      kind = "old_road",
      path_index = 0,
      purpose = "region_connector",
      route_cells = {
        {
          12,
          14,
        },
        {
          11,
          14,
        },
        {
          10,
          14,
        },
        {
          9,
          14,
        },
        {
          8,
          14,
        },
        {
          7,
          14,
        },
        {
          6,
          14,
        },
        {
          5,
          14,
        },
        {
          4,
          14,
        },
        {
          3,
          14,
        },
        {
          2,
          14,
        },
        {
          2,
          13,
        },
        {
          2,
          12,
        },
      },
      sector = {
        2,
        1,
      },
      visual_material = "road",
    },
    {
      anchors = {
        {
          coord = 12,
          edge = "N",
          to = {
            2,
            1,
          },
          x = 12,
          y = 0,
        },
      },
      corridor_id = "corridor_02_old_road",
      kind = "old_road",
      path_index = 1,
      purpose = "region_connector",
      route_cells = {
        {
          12,
          0,
        },
        {
          11,
          0,
        },
        {
          10,
          0,
        },
        {
          9,
          0,
        },
        {
          9,
          1,
        },
        {
          9,
          2,
        },
        {
          9,
          3,
        },
        {
          9,
          4,
        },
        {
          8,
          4,
        },
        {
          8,
          5,
        },
        {
          7,
          5,
        },
        {
          6,
          5,
        },
        {
          5,
          5,
        },
        {
          5,
          6,
        },
        {
          4,
          6,
        },
        {
          4,
          7,
        },
        {
          3,
          7,
        },
        {
          3,
          8,
        },
        {
          3,
          9,
        },
        {
          2,
          9,
        },
        {
          2,
          10,
        },
        {
          2,
          11,
        },
        {
          2,
          12,
        },
      },
      sector = {
        2,
        2,
      },
      visual_material = "road",
    },
    {
      anchors = {
        {
          coord = 9,
          edge = "W",
          to = {
            4,
            4,
          },
          x = 0,
          y = 9,
        },
      },
      corridor_id = "corridor_03_old_road",
      kind = "old_road",
      path_index = 0,
      purpose = "region_connector",
      route_cells = {
        {
          0,
          9,
        },
        {
          0,
          10,
        },
        {
          0,
          11,
        },
        {
          1,
          11,
        },
        {
          2,
          11,
        },
        {
          2,
          12,
        },
      },
      sector = {
        5,
        4,
      },
      visual_material = "road",
    },
    {
      anchors = {
        {
          coord = 9,
          edge = "E",
          to = {
            5,
            4,
          },
          x = 19,
          y = 9,
        },
        {
          coord = 8,
          edge = "N",
          to = {
            4,
            3,
          },
          x = 8,
          y = 0,
        },
      },
      corridor_id = "corridor_03_old_road",
      kind = "old_road",
      path_index = 1,
      purpose = "region_connector",
      route_cells = {
        {
          19,
          9,
        },
        {
          19,
          8,
        },
        {
          19,
          7,
        },
        {
          18,
          7,
        },
        {
          18,
          6,
        },
        {
          17,
          6,
        },
        {
          16,
          6,
        },
        {
          15,
          6,
        },
        {
          14,
          6,
        },
        {
          13,
          6,
        },
        {
          12,
          6,
        },
        {
          11,
          6,
        },
        {
          10,
          6,
        },
        {
          9,
          6,
        },
        {
          8,
          6,
        },
        {
          8,
          5,
        },
        {
          8,
          4,
        },
        {
          8,
          3,
        },
        {
          8,
          2,
        },
        {
          8,
          1,
        },
        {
          8,
          0,
        },
      },
      sector = {
        4,
        4,
      },
      visual_material = "road",
    },
    {
      anchors = {
        {
          coord = 8,
          edge = "S",
          to = {
            4,
            4,
          },
          x = 8,
          y = 14,
        },
        {
          coord = 10,
          edge = "W",
          to = {
            3,
            3,
          },
          x = 0,
          y = 10,
        },
      },
      corridor_id = "corridor_03_old_road",
      kind = "old_road",
      path_index = 2,
      purpose = "region_connector",
      route_cells = {
        {
          8,
          14,
        },
        {
          7,
          14,
        },
        {
          6,
          14,
        },
        {
          5,
          14,
        },
        {
          4,
          14,
        },
        {
          3,
          14,
        },
        {
          2,
          14,
        },
        {
          1,
          14,
        },
        {
          0,
          14,
        },
        {
          0,
          13,
        },
        {
          0,
          12,
        },
        {
          0,
          11,
        },
        {
          0,
          10,
        },
      },
      sector = {
        4,
        3,
      },
      visual_material = "road",
    },
    {
      anchors = {
        {
          coord = 10,
          edge = "E",
          to = {
            4,
            3,
          },
          x = 19,
          y = 10,
        },
        {
          coord = 4,
          edge = "N",
          to = {
            3,
            2,
          },
          x = 4,
          y = 0,
        },
      },
      corridor_id = "corridor_03_old_road",
      kind = "old_road",
      path_index = 3,
      purpose = "region_connector",
      route_cells = {
        {
          19,
          10,
        },
        {
          18,
          10,
        },
        {
          17,
          10,
        },
        {
          16,
          10,
        },
        {
          16,
          9,
        },
        {
          16,
          8,
        },
        {
          15,
          8,
        },
        {
          14,
          8,
        },
        {
          13,
          8,
        },
        {
          12,
          8,
        },
        {
          12,
          7,
        },
        {
          12,
          6,
        },
        {
          11,
          6,
        },
        {
          10,
          6,
        },
        {
          9,
          6,
        },
        {
          8,
          6,
        },
        {
          7,
          6,
        },
        {
          6,
          6,
        },
        {
          6,
          5,
        },
        {
          5,
          5,
        },
        {
          4,
          5,
        },
        {
          4,
          4,
        },
        {
          4,
          3,
        },
        {
          4,
          2,
        },
        {
          4,
          1,
        },
        {
          4,
          0,
        },
      },
      sector = {
        3,
        3,
      },
      visual_material = "road",
    },
    {
      anchors = {
        {
          coord = 4,
          edge = "S",
          to = {
            3,
            3,
          },
          x = 4,
          y = 14,
        },
      },
      corridor_id = "corridor_03_old_road",
      kind = "old_road",
      path_index = 4,
      purpose = "region_connector",
      route_cells = {
        {
          4,
          14,
        },
        {
          3,
          14,
        },
        {
          2,
          14,
        },
        {
          2,
          13,
        },
        {
          2,
          12,
        },
      },
      sector = {
        3,
        2,
      },
      visual_material = "road",
    },
    {
      anchors = {
        {
          coord = 12,
          edge = "N",
          to = {
            0,
            3,
          },
          x = 12,
          y = 0,
        },
      },
      corridor_id = "corridor_04_pilgrim_route",
      kind = "pilgrim_route",
      path_index = 0,
      purpose = "region_connector",
      route_cells = {
        {
          12,
          0,
        },
        {
          11,
          0,
        },
        {
          10,
          0,
        },
        {
          9,
          0,
        },
        {
          8,
          0,
        },
        {
          8,
          1,
        },
        {
          8,
          2,
        },
        {
          8,
          3,
        },
        {
          7,
          3,
        },
        {
          6,
          3,
        },
        {
          6,
          4,
        },
        {
          6,
          5,
        },
        {
          5,
          5,
        },
        {
          4,
          5,
        },
        {
          3,
          5,
        },
        {
          3,
          6,
        },
        {
          3,
          7,
        },
        {
          2,
          7,
        },
        {
          2,
          8,
        },
        {
          2,
          9,
        },
        {
          2,
          10,
        },
        {
          2,
          11,
        },
        {
          2,
          12,
        },
      },
      sector = {
        0,
        4,
      },
      visual_material = "pilgrim_paving",
    },
    {
      anchors = {
        {
          coord = 12,
          edge = "S",
          to = {
            0,
            4,
          },
          x = 12,
          y = 14,
        },
        {
          coord = 7,
          edge = "N",
          to = {
            0,
            2,
          },
          x = 7,
          y = 0,
        },
      },
      corridor_id = "corridor_04_pilgrim_route",
      kind = "pilgrim_route",
      path_index = 1,
      purpose = "region_connector",
      route_cells = {
        {
          12,
          14,
        },
        {
          11,
          14,
        },
        {
          10,
          14,
        },
        {
          9,
          14,
        },
        {
          8,
          14,
        },
        {
          8,
          13,
        },
        {
          8,
          12,
        },
        {
          8,
          11,
        },
        {
          7,
          11,
        },
        {
          7,
          10,
        },
        {
          7,
          9,
        },
        {
          7,
          8,
        },
        {
          7,
          7,
        },
        {
          7,
          6,
        },
        {
          7,
          5,
        },
        {
          7,
          4,
        },
        {
          7,
          3,
        },
        {
          7,
          2,
        },
        {
          7,
          1,
        },
        {
          7,
          0,
        },
      },
      sector = {
        0,
        3,
      },
      visual_material = "pilgrim_paving",
    },
    {
      anchors = {
        {
          coord = 7,
          edge = "S",
          to = {
            0,
            3,
          },
          x = 7,
          y = 14,
        },
      },
      corridor_id = "corridor_04_pilgrim_route",
      kind = "pilgrim_route",
      path_index = 2,
      purpose = "region_connector",
      route_cells = {
        {
          7,
          14,
        },
        {
          6,
          14,
        },
        {
          5,
          14,
        },
        {
          4,
          14,
        },
        {
          3,
          14,
        },
        {
          2,
          14,
        },
        {
          2,
          13,
        },
        {
          2,
          12,
        },
      },
      sector = {
        0,
        2,
      },
      visual_material = "pilgrim_paving",
    },
    {
      anchors = {
        {
          coord = 6,
          edge = "W",
          to = {
            0,
            0,
          },
          x = 0,
          y = 6,
        },
      },
      corridor_id = "corridor_05_silt_vein",
      kind = "silt_vein",
      path_index = 0,
      purpose = "landmark_spur",
      route_cells = {
        {
          0,
          6,
        },
        {
          0,
          7,
        },
        {
          0,
          8,
        },
        {
          1,
          8,
        },
        {
          1,
          9,
        },
        {
          1,
          10,
        },
        {
          2,
          10,
        },
        {
          2,
          11,
        },
        {
          2,
          12,
        },
      },
      sector = {
        1,
        0,
      },
      visual_material = "silt_trace",
    },
    {
      anchors = {
        {
          coord = 6,
          edge = "E",
          to = {
            1,
            0,
          },
          x = 19,
          y = 6,
        },
      },
      corridor_id = "corridor_05_silt_vein",
      kind = "silt_vein",
      path_index = 1,
      purpose = "landmark_spur",
      route_cells = {
        {
          19,
          6,
        },
        {
          18,
          6,
        },
        {
          17,
          6,
        },
        {
          16,
          6,
        },
        {
          15,
          6,
        },
        {
          14,
          6,
        },
        {
          13,
          6,
        },
        {
          12,
          6,
        },
        {
          11,
          6,
        },
        {
          11,
          7,
        },
        {
          10,
          7,
        },
        {
          9,
          7,
        },
        {
          8,
          7,
        },
        {
          7,
          7,
        },
        {
          6,
          7,
        },
        {
          5,
          7,
        },
        {
          4,
          7,
        },
        {
          4,
          8,
        },
        {
          4,
          9,
        },
        {
          4,
          10,
        },
        {
          4,
          11,
        },
        {
          3,
          11,
        },
        {
          2,
          11,
        },
        {
          2,
          12,
        },
      },
      sector = {
        0,
        0,
      },
      visual_material = "silt_trace",
    },
    {
      anchors = {
        {
          coord = 6,
          edge = "W",
          to = {
            4,
            0,
          },
          x = 0,
          y = 6,
        },
      },
      corridor_id = "corridor_06_silt_vein",
      kind = "silt_vein",
      path_index = 0,
      purpose = "landmark_spur",
      route_cells = {
        {
          0,
          6,
        },
        {
          0,
          7,
        },
        {
          1,
          7,
        },
        {
          1,
          8,
        },
        {
          1,
          9,
        },
        {
          2,
          9,
        },
        {
          2,
          10,
        },
        {
          2,
          11,
        },
        {
          2,
          12,
        },
      },
      sector = {
        5,
        0,
      },
      visual_material = "silt_trace",
    },
    {
      anchors = {
        {
          coord = 6,
          edge = "E",
          to = {
            5,
            0,
          },
          x = 19,
          y = 6,
        },
        {
          coord = 6,
          edge = "W",
          to = {
            3,
            0,
          },
          x = 0,
          y = 6,
        },
      },
      corridor_id = "corridor_06_silt_vein",
      kind = "silt_vein",
      path_index = 1,
      purpose = "landmark_spur",
      route_cells = {
        {
          19,
          6,
        },
        {
          18,
          6,
        },
        {
          17,
          6,
        },
        {
          16,
          6,
        },
        {
          15,
          6,
        },
        {
          14,
          6,
        },
        {
          14,
          7,
        },
        {
          13,
          7,
        },
        {
          12,
          7,
        },
        {
          11,
          7,
        },
        {
          10,
          7,
        },
        {
          9,
          7,
        },
        {
          8,
          7,
        },
        {
          7,
          7,
        },
        {
          6,
          7,
        },
        {
          5,
          7,
        },
        {
          4,
          7,
        },
        {
          3,
          7,
        },
        {
          2,
          7,
        },
        {
          2,
          8,
        },
        {
          1,
          8,
        },
        {
          0,
          8,
        },
        {
          0,
          7,
        },
        {
          0,
          6,
        },
      },
      sector = {
        4,
        0,
      },
      visual_material = "silt_trace",
    },
    {
      anchors = {
        {
          coord = 6,
          edge = "E",
          to = {
            4,
            0,
          },
          x = 19,
          y = 6,
        },
        {
          coord = 6,
          edge = "W",
          to = {
            2,
            0,
          },
          x = 0,
          y = 6,
        },
      },
      corridor_id = "corridor_06_silt_vein",
      kind = "silt_vein",
      path_index = 2,
      purpose = "landmark_spur",
      route_cells = {
        {
          19,
          6,
        },
        {
          18,
          6,
        },
        {
          17,
          6,
        },
        {
          16,
          6,
        },
        {
          15,
          6,
        },
        {
          14,
          6,
        },
        {
          13,
          6,
        },
        {
          12,
          6,
        },
        {
          11,
          6,
        },
        {
          10,
          6,
        },
        {
          9,
          6,
        },
        {
          8,
          6,
        },
        {
          7,
          6,
        },
        {
          6,
          6,
        },
        {
          5,
          6,
        },
        {
          4,
          6,
        },
        {
          3,
          6,
        },
        {
          2,
          6,
        },
        {
          1,
          6,
        },
        {
          0,
          6,
        },
      },
      sector = {
        3,
        0,
      },
      visual_material = "silt_trace",
    },
    {
      anchors = {
        {
          coord = 6,
          edge = "E",
          to = {
            3,
            0,
          },
          x = 19,
          y = 6,
        },
        {
          coord = 6,
          edge = "W",
          to = {
            1,
            0,
          },
          x = 0,
          y = 6,
        },
      },
      corridor_id = "corridor_06_silt_vein",
      kind = "silt_vein",
      path_index = 3,
      purpose = "landmark_spur",
      route_cells = {
        {
          19,
          6,
        },
        {
          18,
          6,
        },
        {
          17,
          6,
        },
        {
          16,
          6,
        },
        {
          15,
          6,
        },
        {
          14,
          6,
        },
        {
          13,
          6,
        },
        {
          12,
          6,
        },
        {
          12,
          7,
        },
        {
          11,
          7,
        },
        {
          10,
          7,
        },
        {
          9,
          7,
        },
        {
          8,
          7,
        },
        {
          7,
          7,
        },
        {
          6,
          7,
        },
        {
          5,
          7,
        },
        {
          4,
          7,
        },
        {
          3,
          7,
        },
        {
          3,
          8,
        },
        {
          2,
          8,
        },
        {
          1,
          8,
        },
        {
          0,
          8,
        },
        {
          0,
          7,
        },
        {
          0,
          6,
        },
      },
      sector = {
        2,
        0,
      },
      visual_material = "silt_trace",
    },
    {
      anchors = {
        {
          coord = 6,
          edge = "E",
          to = {
            2,
            0,
          },
          x = 19,
          y = 6,
        },
      },
      corridor_id = "corridor_06_silt_vein",
      kind = "silt_vein",
      path_index = 4,
      purpose = "landmark_spur",
      route_cells = {
        {
          19,
          6,
        },
        {
          18,
          6,
        },
        {
          17,
          6,
        },
        {
          17,
          7,
        },
        {
          16,
          7,
        },
        {
          15,
          7,
        },
        {
          14,
          7,
        },
        {
          13,
          7,
        },
        {
          12,
          7,
        },
        {
          11,
          7,
        },
        {
          10,
          7,
        },
        {
          9,
          7,
        },
        {
          8,
          7,
        },
        {
          7,
          7,
        },
        {
          6,
          7,
        },
        {
          5,
          7,
        },
        {
          5,
          8,
        },
        {
          4,
          8,
        },
        {
          4,
          9,
        },
        {
          4,
          10,
        },
        {
          4,
          11,
        },
        {
          3,
          11,
        },
        {
          2,
          11,
        },
        {
          2,
          12,
        },
      },
      sector = {
        1,
        0,
      },
      visual_material = "silt_trace",
    },
    {
      anchors = {
        {
          coord = 5,
          edge = "N",
          to = {
            2,
            2,
          },
          x = 5,
          y = 0,
        },
      },
      corridor_id = "corridor_07_silt_vein",
      kind = "silt_vein",
      path_index = 0,
      purpose = "landmark_spur",
      route_cells = {
        {
          5,
          0,
        },
        {
          4,
          0,
        },
        {
          3,
          0,
        },
        {
          2,
          0,
        },
        {
          2,
          1,
        },
        {
          2,
          2,
        },
        {
          2,
          3,
        },
        {
          2,
          4,
        },
        {
          2,
          5,
        },
        {
          2,
          6,
        },
        {
          2,
          7,
        },
        {
          2,
          8,
        },
        {
          2,
          9,
        },
        {
          2,
          10,
        },
        {
          2,
          11,
        },
        {
          2,
          12,
        },
      },
      sector = {
        2,
        3,
      },
      visual_material = "silt_trace",
    },
    {
      anchors = {
        {
          coord = 5,
          edge = "S",
          to = {
            2,
            3,
          },
          x = 5,
          y = 14,
        },
      },
      corridor_id = "corridor_07_silt_vein",
      kind = "silt_vein",
      path_index = 1,
      purpose = "landmark_spur",
      route_cells = {
        {
          5,
          14,
        },
        {
          4,
          14,
        },
        {
          3,
          14,
        },
        {
          2,
          14,
        },
        {
          2,
          13,
        },
        {
          2,
          12,
        },
      },
      sector = {
        2,
        2,
      },
      visual_material = "silt_trace",
    },
  },
  policy = {
    enabled = true,
    invariant = "global corridor topology fixed first; local scene realizes it without changing sector order",
    landmark_spurs = "uncovered regional/world landmarks connect to macro network",
    local_realization = "actual world link anchors joined by walkable local scene routes",
    regional_connectors = "each region center connects to existing macro network",
    topology = "deterministic weighted 4-neighbor sector paths",
    world_spine = "start sector to world landmark or opposite corner",
  },
  summary = {
    corridor_count = 7,
    covered_sector_count = 19,
    kind_counts = {
      old_road = 3,
      pilgrim_route = 1,
      silt_vein = 3,
    },
    local_segment_count = 25,
  },
  version = "0.9.0",
}
